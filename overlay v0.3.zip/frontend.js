const app = Vue.createApp({
    //DATA & DEFINITIONS
    data() {
        return {
            ready  : false,
            mapper : null,
            bench: [0, 1, 2, 3, 4, 5],
            hand: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59],
        
            // Toggles
            toggle_deck_list: true,
            toggle_hand     : false,
            toggle_prize    : false,

            card_data: card_data,
        }
    },

    computed: {
        energy_player_arena() { return this.get_energy('player', 'Arena')},
        energy_player_bench() { return [this.get_energy('player', 'Bench_1'), this.get_energy('player', 'Bench_2'), this.get_energy('player', 'Bench_3'), this.get_energy('player', 'Bench_4'), this.get_energy('player', 'Bench_5')]},
        energy_opponent_arena() { return this.get_energy('opponent', 'Arena')},
        energy_opponent_bench() { return [this.get_energy('opponent', 'Bench_1'), this.get_energy('opponent', 'Bench_2'), this.get_energy('opponent', 'Bench_3'), this.get_energy('opponent', 'Bench_4'), this.get_energy('opponent', 'Bench_5')]},
        get_overworld_deck_1() {
            const cardCounts = {};
            const cardProperties = this.mapper.properties.player.deck_1
            Object.values(cardProperties).forEach(card => {
                // If the card doesn't exist yet in cardCounts, initialize it to 0
                if (!cardCounts[card]) {
                    cardCounts[card] = 0;
                }
                cardCounts[card]++;
            });

            // console.log(cardCounts);

            return cardCounts
        },
        get_player_deck() {
            const cardCounts = {};
            const cardProperties = this.mapper.properties.player.deck
            Object.values(cardProperties).forEach(card => {
                // If the card doesn't exist yet in cardCounts, initialize it to 0
                if (!cardCounts[card]) {
                    cardCounts[card] = 0;
                }
                cardCounts[card]++;
            });

            // console.log(cardCounts);

            return cardCounts
        },
        get_opponent_deck() {
            const cardCounts = {};
            const cardProperties = this.mapper.properties.opponent.deck
            Object.values(cardProperties).forEach(card => {
                // If the card doesn't exist yet in cardCounts, initialize it to 0
                if (!cardCounts[card]) {
                    cardCounts[card] = 0;
                }
                cardCounts[card]++;
            });

            // console.log(cardCounts);

            return cardCounts
        },
    },

    methods: {
        calculate_damage_counters(user) {
            const hp = this.mapper.properties[user].hp.ArenaCardHP.value
            const card_data = this.card_data
            const card_name = this.mapper.properties[user].arena_pokemon.value
            if (card_name == undefined) { return }
            const total_hp = card_data[card_name].hp
            const damage = total_hp - hp
            return damage / 10
        },
        calculate_benched_damage_counters(user, slot) {
            const hp = this.mapper.properties[user].hp[`Bench${slot + 1}CardHP`].value
            if (hp == 0) { return 0 }
            const card_data = this.card_data
            const card_name = this.mapper.properties[user].bench[slot].value
            if (card_name == undefined) { return }
            const total_hp = card_data[card_name].hp
            console.log(total_hp)
            const damage = total_hp - hp
            return damage / 10
        },
        get_energy(user, location) {
            const deck = this.mapper.properties[user].deck
            const card_locations = this.mapper.properties[user].card_locations
            const result_array = []
            for (let i = 0; i < card_locations.length; i++) {
                if (card_locations[i].value === location) {
                    if (deck[i].value === 'DOUBLE_COLORLESS_ENERGY') {
                        result_array.push(deck[i].value)
                    }
                    result_array.push(deck[i].value)
                }
            }
            return result_array.filter(item => item.includes('ENERGY'))
        },
        countSetBits(byte) {
            let count = 0;
            while (byte) {
                count += byte & 1; // Check if the least significant bit is set
                byte >>= 1;        // Shift the byte to the right by 1
            }
            return count;
        },
        capitalization_format(str) {
            if (str == null) { return "" }
            return str
                .toLowerCase()
                .replace(/_/g, ' ') // Replace underscores with spaces
                .replace(/(^|\s|\-|\.)(\w)/g, function(match, p1, p2) {
                    return p1 + p2.toUpperCase();
                });
        },
        imposter(card_name) {
            if (card_name == 'Imposter Professor Oak') {
                return 'Imp. Prof. Oak'
            }
            else return card_name
        }
    },

    mounted: async function () {
        const that = this
        this.mapper = new GameHookMapperClient()
        this.mapper.onConnected = (x) => this.ready = true
        this.mapper.onDisconnected = (x) => this.ready = false
        await this.mapper.connect()
    },

}).mount('#app')